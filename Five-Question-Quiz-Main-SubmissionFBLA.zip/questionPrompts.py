
#-------------------------------------------------------------#
#-----------------Prompt to run objects----------------#
#the prompts used to make the quiz.

#---------------------------------------------------------
      #10 questions total -- Multiple Choice prompt 
#---------------------------------------------------------
pM= [
    
     "What is 3+1?", #question0
     
     "What is 10-3?", #question1
     
     "How do you write the number 79 in words?", #question2

     "What is 14-6?", #question3

     "What is 82-6?", #question4

     "What is 99-8?", #question5

     "What is 15+7?", #question6

     "What is 10+31?", #question7

     "What is 12+19?", #question8

     "What is 11+91?", #question9
]
#---------------------------------------------------------
      #10 questions total -- Multiple Choice prompt 
#---------------------------------------------------------

pMA=[
[("(a)2"),("(b)4"),("(c)5"),("(d)10")], #Ans0

[("(a)2"),("(b)7"),("(c)6"),("(d)10")], #Ans1

[("(a)seven-nine"),("(b)ninety-seven"),("(c)nine-seven"),("(d)seventy-nine")], #Ans2

[("(a)8"),("(b)10"),("(c)12"),("(d)6")], #Ans3

[("(a)78"),("(b)88"),("(c)76"),("(d)74")], #Ans4

[("(a)72"),("(b)92"),("(c)91"),("(d)90")], #Ans5

[("(a)22"),("(b)21"),("(c)24"),("(d)23")], #Ans6

[("(a)44"),("(b)31"),("(c)41"),("(d)51")], #Ans7

[("(a)21"),("(b)20"),("(c)31"),("(d)24")], #Ans8

[("(a)101"),("(b)-102"),("(c)102"),("(d)104")], #Ans9
]
#---------------------------------------------------------
              #Multiple Choice Correct Ans 
#---------------------------------------------------------

pMCA=[
("(b)4"), #CorrectAns0 (b)
("(b)7"), #CorrectAns1 (b)
("(d)seventy-nine"), #CorrectAns2 (d)
("(a)8"), #CorrectAns3 (a)
("(c)76"), #CorrectAns4 (c)
("(c)91"), #CorrectAns5 (c)
("(a)22"), #CorrectAns6 (a)
("(c)41"), #CorrectAns7 (c)
("(c)31"), #CorrectAns8 (c)
("(c)102"), #CorrectAns9 (c)
]
#---------------------------------------------------------
              #Multiple Choice Correct Ans 
#--------------------------------------------------------

pYN= [


     "Does 10+11= 25?", #question0

     "Does 12+3=14?", #question1
     
     "Does 57+13=71?", #question2

     "Does 49+13=62?", #question3

     "Does 123+32=143?", #question4

     "Does 12+181=193?", #question5

     "Does 100+32=132?", #question6

     "Does 62-12=50?", #question7

     "Does 59-10=50?", #question8

     "Does 62+8=70?", #question9
]
#---------------------------------------------------------
          #10 questions total -- YES/NO prompt 
#---------------------------------------------------------

pYNA=[

[("Yes"),("No")], #Ans0

[("Yes"),("No")], #Ans1

[("Yes"),("No")], #Ans2

[("Yes"),("No")], #Ans3

[("Yes"),("No")], #Ans4

[("Yes"),("No")], #Ans5

[("Yes"),("No")], #Ans6

[("Yes"),("No")], #Ans7

[("Yes"),("No")], #Ans8

[("Yes"),("No")], #Ans9
]
#---------------------------------------------------------
          #10 questions total -- YES/NO ANS 
#---------------------------------------------------------

pYNCa=[
("No"), #CorrectAns0
("No"), #CorrectAns1
("No"), #CorrectAns2
("Yes"), #CorrectAns3
("No"), #CorrectAns4
("Yes"), #CorrectAns5
("Yes"), #CorrectAns6
("Yes"), #CorrectAns7
("No"), #CorrectAns8
("Yes"), #CorrectAns9
]
#---------------------------------------------------------
       #10 questions total -- YES/NO Correct ANS 
#---------------------------------------------------------

pTFa=[

     "True or False: 11+2=14", #question0

     "True or False: 12+12=24", #question1
     
     "True or False: 5+9=14", #question2

     "True or False: 6+4=11", #question3

     "True or False: 93+8=101", #question4

     "True or False: 62-12=51", #question5

     "True or False: 31+22=53",#question6

     "True or False: 43+7=-50", #question7

     "True or False: 82+7=88", #question8

     "True or False: 90+9=100", #question9
]
#---------------------------------------------------------
       #10 questions total -- True/False Prompt 
#---------------------------------------------------------

pTFaa=[
[("True"),("False")], #Ans0

[("True"),("False")], #Ans1

[("True"),("False")], #Ans2

[("True"),("False")], #Ans3

[("True"),("False")], #Ans4

[("True"),("False")], #Ans5

[("True"),("False")], #Ans6

[("True"),("False")], #Ans7

[("True"),("False")], #Ans8

[("True"),("False")], #Ans9
]
#---------------------------------------------------------
       #10 questions total -- True/False ANS 
#---------------------------------------------------------

pTFaCa=[
("False"),
("True"),
("True"),
("False"),
("True"),
("False"),
("True"),
("False"),
("False"),
("False"),
]
#---------------------------------------------------------
       #10 questions total -- True/False Correct ANS 
#---------------------------------------------------------

pFTB= [

     "What is missing: 7+__=12", #question0

     "What is missing: 6+__=15", #question1
     
     "What is missing 5+__=12", #question2

     "What is missing 8+__=13", #question3

     "What is missing 58-__=49", #question4

     "What is missing 47-__=39", #question5

     "What is missing 94-__=80", #question6

     "What is missing 75-__=60", #question7

     "What is missing 90+__=99", #question8

     "What is missing 54+__=86", #question9
]
#---------------------------------------------------------
       #10 questions total -- Fill in the Blank Prompt
#---------------------------------------------------------

pFTBa=[
[("(a)-4"),("(b)4"),("(c)-5"),("(d)5")],

[("(a)6"),("(b)-6"),("(c)-9"),("(d)9")],

[("(a)1"),("(b)5"),("(c)8"),("(d)7")],

[("(a)4"),("(b)6"),("(c)5"),("(d)-5")],

[("(a)7"),("(b)-9"),("(c)9"),("(d)8")],

[("(a)7"),("(b)-7"),("(c)-8"),("(d)8")],

[("(a)13"),("(b)12"),("(c)14"),("(d)-14")],

[("(a)12"),("(b)10"),("(c)13"),("(d)15")],

[("(a)7"),("(b)-9"),("(c)9"),("(d)10")],

[("(a)31"),("(b)-31"),("(c)-32"),("(d)32")],
]
#---------------------------------------------------------
       #10 questions total -- Fill in the Blank ANS 
#---------------------------------------------------------

pFTBCa=[
("5"), #d
("9"), #d
("7"), #d
("5"), #c
("9"), #c
("8"), #d
("14"), #c
("15"), #d
("9"), #c
("32"), #d
]
#---------------------------------------------------------
       #10 questions total -- Fill in the Blank Correct ANS  
#---------------------------------------------------------

pDD= [
     
     "What is 11-18?", #question0

     "What is 101-11?", #question1

     "What is 21+1.2?", #question2

     "What is 31-11?", #question3

     "What is 9+11?", #question4

     "What is 81-11?", #question5

     "What is 32+8?", #question6

     "What is 51+8?", #question7

     "What is 81-10?", #question8

     "What is 54+32?",#question9
]
#---------------------------------------------------------
       #10 questions total -- Drop Down Prompt  
#---------------------------------------------------------

pDDa=[
[("(a)-7"),("(b)7"),("(c)8"),("(d)-8")],
[("(a)91"),("(b)-90"),("(c)90"),("(d)-89")],
[("(a)21.1"),("(b)22.2"),("(c)22.1"),("(d)23.1")],
[("(a)20"),("(b)19"),("(c)21"),("(d)20.1")],
[("(a)19"),("(b)20"),("(c)21"),("(d)91")],
[("(a)70"),("(b)71"),("(c)81"),("(d)71")],
[("(a)41"),("(b)40"),("(c)38"),("(d)-40")],
[("(a)55"),("(b)54"),("(c)59"),("(d)60")],
[("(a)75"),("(b)72"),("(c)71"),("(d)81")],
[("(a)84"),("(b)76"),("(c)-86"),("(d)86")],
]
#---------------------------------------------------------
       #10 questions total -- Drop Down ANS  
#---------------------------------------------------------

pDDCa=[
"(a)-7",
"(c)90",
"(b)22.2",
"(a)20",
"(b)20",
"(a)70",
"(b)40",
"(c)59",
"(c)71",
"(d)86",
]
#---------------------------------------------------------
       #10 questions total -- Drop Down Correct ANS  
#---------------------------------------------------------