#------------------------------------------------------
 #import Statements ---------------------------------------------------------
from tkinter import *        #Imports
import random as rand        #Necessary
import questionPrompts as qp #Files
from tkinter import *        #For
from tkinter import ttk      #Program
#------------------------------------------------------
 #import Statements ---------------------------------------------------------
#
  #
    #---
#
#
#
    #---
  #
#
#---------------------------------------------------------
 #Root variable strings (to call and changed titles and Labels)---------------------------------------------------------
root = Tk()                                     # Creates
root.title("***Collin's Five Question Quiz***") # A window
tkvar = StringVar(root)                         #+Title
#---------------------------------------------------------
 #Root variable strings (to call and changed titles and Labels)---------------------------------------------------------
#---------
  #     #     #     #     #     #     #     #     #     #
#---------
#---------------------------------------------------------
 #opening and reading the proper lists to import them for the quiz from another file. ---------------------------------------------------------
currentQuestionMult=qp.pM         #Imports
currentQuestionYN=qp.pYN          #Current 
currentQuestionTF=qp.pTFa         #Question
currentQuestionFTB=qp.pFTB        #Prompts
currentQuestionDD=qp.pDD          #From qp -questionPrompts
#---------------------------------------------------------
 #opening and reading the proper lists to import them for the quiz from another file. ---------------------------------------------------------


#---------------------------------------------------------
 #init the Frames that hold each varible (tabs)---------------------------------------------------------
global subFinal                 #Initilizing
global selectedAnsM             #Global
global selectedAnsYN            #Variables
global selectedAnsTF            #---------
global selectedAnsFTB           #Usable 
global selectedAnsDD            #Anywhere
global submittedAnsM            #Inside
global submittedAnsYN           #Of
global submittedAnsTF           #The
global submittedAnsFTB          #Program
global submittedAnsDD           #---------
global aFTB                     #--------- 
global aFTB_var                 #---------
global total                    #Total counter - For scoring
#---------
  #     #     #     #     #     #     #     #     #     #
#---------
y=0                             #Defining 
selectedAnsM = "no ANS"         #Variables
selectedAnsYN = "no ANS"        #Default
selectedAnsTF = "no ANS"        #---------
selectedAnsFTB = "no ANS"       #---------
selectedAnsDD = "no ANS"        #---------
aFTB_var = StringVar()          # =A string and variable
aFTB=aFTB_var.get()             #Get the FTB input(Defining)
submittedAnsM=selectedAnsM      #Creating
submittedAnsYN=selectedAnsYN    #Varibles
submittedAnsTF=selectedAnsTF    #For 
submittedAnsFTB=aFTB            #FInal
submittedAnsDD=tkvar.get()      #Submission
  #     #     #     #     #     #     #     #     #     #
n= ttk.Notebook()               #Creating
f1= ttk.Frame(n)                #A
f2= ttk.Frame(n)                #Workplace
f3= ttk.Frame(n)                #Using
f4= ttk.Frame(n)                #Tkinter
f5= ttk.Frame(n)                #Frames
f6= ttk.Frame(n)                #+
f9= ttk.Frame(n)                #Entries
window= ttk.Frame(n)            #---------
#---------------------------------------------------------
 #init the Frames that hold each varible (tabs)---------------------------------------------------------
#---------
  #     #     #     #     #     #     #     #     #     #
#---------
#---------------------------------------------------------
 #Tabs for organization of the Questions 1-5 + global int ---------------------------------------------------------
def main(x):
    global selectedAnsM 
    global total
    global score
    global subFinal
    global iOCQM
    global cPM
    global cCAM
    global cAM
    global iOCQYN
    global cPYN
    global cCAYN
    global cAYN
    global iOCQTF
    global cPTF 
    global cCATF
    global cATF
    global iOCQFTB
    global cPFTB
    global cCAFTB
    global cAFTB
    global iOCQDD
    global cPDD
    global cCADD
    global cADD
    global aFTB
    global aFTB_var
    n.add(f1, text="Q #One")
    n.add(f2, text="Q #Two")
    n.add(f3, text="Q #Three")
    n.add(f4, text="Q #Four")
    n.add(f5, text="Q #Five")
    n.add(f6, text="Score Quiz")
    n.add(f9, text="Answer Sheet")
    n.hide(f9)
    total= ttk.Label(window, text="0")
    score=0
    
   #-----------------------------------------------------
    #Tabs for organization of the Questions 1-5 + global int ------------------------------------------------------
#--
  #
#--
   #-----------------------------------------------------
    #variables for Question 1 Multiple Choice Prompt ------------------------------------------------------
    #iOCQM=indexofCurrentQMult
    #cPM=currentPromptMult
    #cCAM=currentCorrectAnsMult
    #cAM=currentAnsMult
    #iOCQM = int(len(qp.promptsM))
    iOCQM=rand.randint(0,len(qp.pM)-1)
    cPM=qp.pM.pop(iOCQM)
    cCAM=qp.pMCA.pop(iOCQM)
    cAM=qp.pMA.pop(iOCQM)
    
   #------------------------------------------------------
    #variables for Question 1 Multiple Choice Prompt ------------------------------------------------------
#--
  #
#--
   #------------------------------------------------------
    #Varibles for Question 2 YES/NO Prompt ------------------------------------------------------
    #iOCQYN=indexofCurrentQYN
    #cPYN=currentPromptYN
    #cCAYN=currentCorrectAnsYN
    #AYN=currentAnsYN
    iOCQYN=rand.randint(0,len(qp.pYN)-1)
    cPYN=qp.pYN.pop(iOCQYN)
    cCAYN=qp.pYNCa.pop(iOCQYN)
    cAYN=qp.pYNA.pop(iOCQYN)
   
   #------------------------------------------------------
    #Varibles for Question 2 YES/NO Prompt ------------------------------------------------------
#--
  #  
#-- 
   #-----------------------------------------------------
     #Variables for Question 3 True/False Prompt -----------------------------------------------------
    #iOCQTF=indexofCurrentQTFa
    #cPTF=currentPromptTFa
    #cCATF=currentCorrectAnsTFa
    #cATF=currentAnsTFa
    iOCQTF=rand.randint(0,len(qp.pTFa)-1)
    cPTF=qp.pTFa.pop(iOCQTF)
    cCATF=qp.pTFaCa.pop(iOCQTF)
    cATF=qp.pTFaa.pop(iOCQTF)
   
   #-----------------------------------------------------
     #Variables for Question 3 True/False Prompt -----------------------------------------------------
#--
  #   
#--
    #-----------------------------------------------------
     #Variables for Question 4 Fill In The Blank Prompt ---------------------------------------------------- 
    #iOCQFTB=indexofCurrentQFillInTheBlank
    #cPFTB=currentPromptFillInTheBlank
    #cCAFTB=currentCorrectAnsFillInTheBlank
    #cAFTB=currentAnsFillInTheBlank
    iOCQFTB=rand.randint(0,len(qp.pFTB)-1)
    cPFTB=qp.pFTB.pop(iOCQFTB)
    cCAFTB=qp.pFTBCa.pop(iOCQFTB)
    cAFTB=qp.pFTBa.pop(iOCQFTB)

   #-----------------------------------------------------
     #Variables for Question 4 Fill In The Blank Prompt ----------------------------------------------------
#--
  #
#--
    #-----------------------------------------------------
     #Variables for Question 5 Drop Down Prompt ----------------------------------------------------
    #iOCQDD=indexofCurrentQDropDown
    #cPDD=currentPromptDropDown
    #cCADD=currentCorrectAnsFillInTheBlank
    #cADD=currentAnsFillInTheBlank
    iOCQDD=rand.randint(0,len(qp.pDD)-1)
    cPDD=qp.pDD.pop(iOCQDD)
    cCADD=qp.pDDCa.pop(iOCQDD)
    cADD=qp.pDDa.pop(iOCQDD)

    #-----------------------------------------------------
     #Variables for Question 5 Drop Down Prompt ----------------------------------------------------


#--                 
  #
#--                 


   #------------------------------------------------------
    #Submit Check Varible ------------------------------------------------------
    subFinal = "Multiple Choice Question:\n" + cPM + "\nMultiple Choice Correct Answers:\n" + cCAM + "\nSelected Answer M:\n" + selectedAnsM + "\nYes/No Choice Question:\n" + cPYN +"\nYes/No Choice Correct Answers:\n" + cCAYN + "\nSelected Answer YN:\n" + selectedAnsYN + "\nTrue/False Choice Question:\n" + cPTF + "\nTrue/False Choice Correct Answers:\n" + cCATF + "\nSelected Answer TF:\n" + selectedAnsTF + "\nFill In The Blank Question:\n" + cPFTB + "\nCorrect Fill In The Blank Question:\n" + cCAFTB + "\nSelected Answer FTB:\n" + selectedAnsFTB + "\nDrop Down Question Prompt:\n" + cPDD + "\nCorrect Drop Down Prompt:\n" + cCADD + "\nSelected Answer Drop Down:\n" + selectedAnsDD
    aFTB_var = StringVar()   
   #------------------------------------------------------
    #Submit Check Varible ------------------------------------------------------
#--
  #
#--
   #------------------------------------------------------
    #Question 1 Multiple Choice Prompt ------------------------------------------------------
    Label(f1,text=cPM).grid(row=2, column=2)
    #A
    Button(f1, text=cAM[0], command=changeAnsA ,bg='#FFFFFF', activebackground='#4444ff').grid(row=3, column=2)
    #B
    Button(f1, text=cAM[1], command=changeAnsB,bg='#FFFFFF', activebackground='#4444ff').grid(row=3,column=4)
    #C
    Button(f1, text=cAM[2], command=changeAnsC,bg='#FFFFFF', activebackground='#4444ff').grid(row=4,column=2)
    #D
    Button(f1,text=cAM[3], command=changeAnsD,bg='#FFFFFF', activebackground='#4444ff').grid(row=4,column=4)
    #Submit
    
    #Button(f1, text="Submit", background="Gold",command=awaitingDecision).grid(row=4, column=6)
   #-----------------------------------------------------
    #Question 1 Multiple Choice Prompt ------------------------------------------------------
#--
  #
#--
   #------------------------------------------------------
    #Question 2 - Y/N Prompt ------------------------------------------------------
    Label(f2, text=cPYN).grid(row = 2, column = 2)
    #Yes
    Button(f2, text=cAYN[0],command=changeAnsY,bg='#FFFFFF', activebackground='#4444ff').grid(row=3,column=2)
    #No
    Button(f2, text=cAYN[1], command=changeAnsN,bg='#FFFFFF', activebackground='#4444ff').grid(row=3,column=4)
    #Submit
    #Button(f2, text="Submit", background="Gold",command=awaitingDecisionYN).grid(row=4, column=6)
   #-----------------------------------------------------
    #Question 2 - Y/N Prompt ------------------------------------------------------

   #------------------------------------------------------
    #Question 3 True/False Prompt ------------------------------------------------------
    Label(f3, text=cPTF).grid(row = 2, column = 2)
    #True
    Button(f3, text=cATF[0],command=changeAnsT,bg='#FFFFFF', activebackground='#4444ff').grid(row=3,column=2)
    #False
    Button(f3, text=cATF[1], command=changeAnsF,bg='#FFFFFF', activebackground='#4444ff').grid(row=3,column=4)
    #Submit
    #Button(f3, text="Submit", background="Gold" ,command=awaitingDecisionTFa).grid(row=4, column=6)
   #------------------------------------------------------
    #Question 3 True/False Prompt ------------------------------------------------------

    #global aFTB
    
    
     
   #------------------------------------------------------
    #Question 4 Fill In The Blank Prompt ------------------------------------------------------
    #Fill In The Blank question insert
    Label(f4, text=cPFTB).grid(row = 2, column = 2)
    # answer label -- organization
    Label(f4, text = 'Answer:', font=('calibre',10, 'bold')).grid(row=3, column=1)
    #entry box 
    aFTB= Entry(f4,textvariable = aFTB_var, font=('calibre',10,'normal'))
    # Submit feature 
    #Button(f4, text="Submit", background="Gold", command=awaitingDecisionFTB).grid(row=4, column=6)
   #------------------------------------------------------
    #Question 4 Fill In The Blank Prompt ------------------------------------------------------


   #------------------------------------------------------
    #Question 5 Drop Down Prompt ------------------------------------------------------
    tkvar.set("--") # set the default option4
    popupMenu = OptionMenu(f5, tkvar, *cADD)
    popupMenu.grid(row = 3, column =2)
    Label(f5, text=cPDD).grid(row = 2, column = 2)
    #Submit
    #Button(f5, text="Submit", background="Gold",command=awaitingDecisionDD).grid(row=4, column=6)
    
   #------------------------------------------------------
    #Question 5 Drop Down Prompt ------------------------------------------------------
    Button(f6, text="Score Quiz:", background="Gold", activebackground= "#444fff", command=FinalSubmission).grid(row=3, column=4)
    #Button(f6, text="Restart", command=main(x)).grid(row=4,column=4)
    #------------------------------------------------------
    #Safe guard -- To reduce error/loopholes (creates answer list)------------------------------------------------------
    Label(f9, text=("Correct Answer Multiple Choice" + "   -  " + cCAM + "\nCorrect Answer Yes/No" + "      -         " + cCAYN + "\nCorrect Answer True/False" + "     -      " + cCATF + "\nCorrect Answer Fill in the Blank" + "   -   " + cCAFTB + "\nCorrect Answer Drop Down" + "   -    " + cCADD)).grid(row=1,column=1)
    aFTB.grid(row=3,column=2)
    return total
    
   #------------------------------------------------------
    #Safe guard -- To reduce error/loopholes (creates answer list)------------------------------------------------------


   #------------------------------------------------------
    #Defines a counter that is used to see how many the user got correct.
    #-----------------------------------------------------
def counter():
    global total
    total['text'] = str(int(total['text']) + 1)
   #------------------------------------------------------
    #Defines a counter that is used to see how many the user got correct.
    #-----------------------------------------------------

#------------------------------------------------------
    #Functions made to check Multiple Choice Question ANS
    #-----------------------------------------------------
def changeAnsA():
  global selectedAnsM
  global cAM
  selectedAnsM=cAM[0]
def changeAnsB():
  global selectedAnsM
  global cAM
  selectedAnsM=cAM[1]
def changeAnsC():
  global selectedAnsM
  global cAM
  selectedAnsM=cAM[2]
def changeAnsD():
  global selectedAnsM
  global cAM
  selectedAnsM=cAM[3]

#------------------------------------------------------
    #Functions made to check Multiple Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check Yes/No Choice Question ANS
    #-----------------------------------------------------
def changeAnsY():
  global selectedAnsYN
  global cAYN
  selectedAnsYN=cAYN[0]
def changeAnsN():
  global selectedAnsYN
  global cAYN
  selectedAnsYN=cAYN[1]
#------------------------------------------------------
    #Functions made to check Yes/No Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check True/False Choice Question ANS
    #-----------------------------------------------------
def changeAnsT():
  global selectedAnsTF
  global cATF
  selectedAnsTF=cATF[0]
def changeAnsF():
  global selectedAnsTF
  global cATF
  selectedAnsTF=cATF[1]
#------------------------------------------------------
    #Functions made to check True/False Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check Fill In The Blank (input statements) Choice Question ANS
    #-----------------------------------------------------

#------------------------------------------------------
    #Functions made to check Fill In The Blank (input statements) Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check Drop Down Choice Question ANS
    #-----------------------------------------------------
def changeAnsDDA():
  global selectedAnsDD
  global cADD
  selectedAnsDD=cADD[0]
def changeAnsDDB():
  global selectedAnsDD
  global cADD
  selectedAnsDD=cADD[1]
def changeAnsDDC():
  global selectedAnsDD
  global cADD
  selectedAnsDD=cADD[2]
def changeAnsDDD():
  global selectedAnsDD
  global cADD
  selectedAnsDD=cADD[3]



#------------------------------------------------------
    #Functions made to check Drop Down Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check Drop Down Choice Question ANS
    #---------------------------------------------------
    

#------------------------------------------------------
    #Functions made to check Drop Down Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check Fill In The Blank Choice Question ANS
    #-----------------------------------------------------


    
#------------------------------------------------------
    #Functions made to check Fill In The Blank Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check True/False Choice Question ANS
    #-----------------------------------------------------

    
#------------------------------------------------------
    #Functions made to check True/False Choice Question ANS
    #-----------------------------------------------------



#------------------------------------------------------
    #Functions made to check Yes/No Choice Question ANS
    #-----------------------------------------------------

    
#------------------------------------------------------
    #Functions made to check Yes/No Choice Question ANS
    #-----------------------------------------------------


#------------------------------------------------------
    #Functions made to check Multiple Choice Question ANS
    #-----------------------------------------------------

    
#------------------------------------------------------
    #Functions made to check Multiple Choice Question ANS
    #-----------------------------------------------------


global correctM
global correctYN
global correctTF
global correctFTB
global correctDD
global incorrectYN
global incorectM
global incorrectTF
global incorrectFTB
global incorrectDD

correctM="Correct - Multiple Choice User Response:\n" + selectedAnsM
correctYN="Correct - Yes/No User Response:\n" + selectedAnsYN
correctTF="Correct - True/False User Response:\n" + selectedAnsTF
correctFTB="Correct - Fill In The Blank User Response:\n" + aFTB
correctDD="Correct - Drop Down User Response:\n" + tkvar.get()

incorrectM="Incorrect - Multiple Choice User Response:\n" + selectedAnsM
incorrectYN="Incorrect - Yes/No User Response:\n" + selectedAnsYN
incorrectTF="Incorrect - True/False User Response:\n" + selectedAnsTF
incorrectFTB="Incorrect - Fill In The Blank User Response:\n" + aFTB
incorrectDD="Incorrect - Drop Down User Response:\n" + tkvar.get()


def updateResponses():
  global subFinal
  global score
  subFinal = "Multiple Choice Question:\n" + cPM + "\nMultiple Choice Correct Answers:\n" + cCAM + "\nSelected Answer M:\n" + selectedAnsM + "\nYes/No Choice Question:\n" + cPYN +"\nYes/No Choice Correct Answers:\n" + cCAYN + "\nSelected Answer YN:\n" + selectedAnsYN + "\nTrue/False Choice Question:\n" + cPTF + "\nTrue/False Choice Correct Answers:\n" + cCATF + "\nSelected Answer TF:\n" + selectedAnsTF + "\nFill In The Blank Question:\n" + cPFTB + "\nCorrect Fill In The Blank Question:\n" + cCAFTB + "\nSelected Answer FTB:\n" + selectedAnsFTB + "\nDrop Down Question Prompt:\n" + cPDD + "\nCorrect Drop Down Prompt:\n" + cCADD + "\nSelected Answer Drop Down:\n" + selectedAnsDD + "\nScore of Quiz:\n" + str(score) 

  with open("aP.txt","w")as f:
    f.write(subFinal)
  

def FinalSubmission():

  global selectedAnsM
  global selectedAnsYN
  global selectedAnsTF
  global selectedAnsFTB
  global selectedAnsDD
  global correctM
  global correctYN
  global correctTF
  global correctFTB
  global correctDD
  global incorrectYN
  global incorectM
  global incorrectTF
  global incorrectFTB
  global incorrectDD
  global score
  global selectedAnsM
  global cCAM
  global score
  global selectedAnsDD
  global cCADD
  global score
  global selectedAnsYN
  global cCAYN
  global score
  global selectedAnsTF
  global cCATF
  global subFinal
  global score
  global selectedAnsFTB
  global cCAFT
  global aFTB
  global aFTB_var 
  global score
  n.add(f9)
  listOfQuestionTabs=[f1,f2,f3,f4,f5]
  for item in listOfQuestionTabs:
    n.hide(item)
  updateResponses()
  score=0
  if selectedAnsM == "no ANS":
    Label(f1, text="Please Select an Answer").grid(row=1, column=2)
  elif selectedAnsM == cCAM:
    Label(f1, text="Correct",).grid(row=1,column=1)
    score+=1
  else:
    Label(f1, text="Incorrect").grid(row=1,column=1)

  if selectedAnsYN == "no ANS":
    Label(f2, text="Please Select an Answer").grid(row=1, column=2)
  elif selectedAnsYN == cCAYN:
    Label(f2, text="Correct",).grid(row=1,column=1)
    score+=1
  else:
    Label(f2, text="Incorrect").grid(row=1,column=1)

  if selectedAnsTF == "no ANS":
    Label(f3, text="Please Select an Answer").grid(row=1, column=2)
  elif selectedAnsTF == cCATF:
    Label(f3, text="Correct",).grid(row=1,column=1)
    score+=1
  else:
    Label(f3, text="Incorrect").grid(row=1,column=1)

  aFTB=aFTB_var.get()
  updateResponses()
  if aFTB == cCAFTB:
    Label(f4, text="Correct",).grid(row=1,column=1)
    score+=1
   
  elif aFTB == "":
    Label(f4,text="Select An Answer").grid(row=1,column=1)
  else:
    Label(f4, text="Incorrect").grid(row=1,column=1)

  if tkvar.get() == cCADD:
    Label(f5, text="Correct",).grid(row=1,column=1)
    score+=1
  elif tkvar.get() == "--":
    Label(f5,text="Select An Answer").grid(row=1,column=1)
  else:
    Label(f5, text="Incorrect").grid(row=1,column=1)
  
  finalScoreLabel=Label(f6, text=score).grid(row=3,column=8)

#--------------------------------------------------------
#Call functions --------------------------------------------------------
main(y)
n.pack()
n.mainloop()
root.mainloop()
#--------------------------------------------------------
  #Call functions --------------------------------------------------------